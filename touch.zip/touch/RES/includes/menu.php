


         <nav>
             <ul>
              <li><a href="contenido4.php" class="nueva-ventana"><span>Nueva Venta</span></a></li>
              <li><a href="contenido2.php" class="cerrar-ventana"><span>Cerrar  Venta</span></a></li>
              <li><a href="contenido3.php" class="devoluciones"><span>Cambios, devoluciones y pedidos</span></a></li>
              <li><a href="contenido.php" class="pagos"><span>Pagos y apartados</span></a></li>
             </ul>  
         </nav>