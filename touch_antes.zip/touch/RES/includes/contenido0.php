<div class="ctn1">
<div class="logo">

  </div>
  </div>
